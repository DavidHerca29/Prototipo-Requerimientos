package com.example.hello_world.data

import retrofit2.Response
import retrofit2.http.GET
import retrofit2.http.Url

/*
    Servicio que realiza la llamada al API, mediante
    URL y devuelve una respuesta del formato especificado
    en incomingData
 */
interface APIService {
    @GET
    suspend fun signinCall(@Url url:String): Response<incomingData>
}