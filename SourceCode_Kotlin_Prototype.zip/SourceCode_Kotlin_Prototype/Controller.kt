package com.example.hello_world

class Controller {

    companion object{

        //Companion object => Equivalente a estatico en java

        /*
            Verifica que el password candidato cumpla:
                - [6, 12] caracteres
                - Caracter especiales: $ # _ - @
                - Contener al menos un digito numerico [0,9]
                - Contener al menos una mayuscula
         */
        fun verifyPassword(passCandidate: String): String {
            var candidateResult = "";

            if(passCandidate.length<6 || passCandidate.length>12){
                candidateResult = "La contraseña debe tener entre 6 y 12 caracteres"
            }else{
                if(passCandidate.indexOfAny(charArrayOf('$','#','_','-','@'))==-1){
                    candidateResult = "La contraseña debe contener al menos un símbolo ($ # _ - @)"
                }else{
                    if(passCandidate.indexOfAny(charArrayOf('0','1','2','3','4','5','6','7','8','9'))==-1){
                        candidateResult = "La contraseña debe contener al menos un número"
                    }else{
                        if(!verifyUpperCase(passCandidate)){
                            candidateResult = "Debe contener al menos una letra mayúscula"
                        }
                    }
                }
            }
            return candidateResult
        }

        /*
            Recibe un String
            Lo descompone
            Busca que este presente una mayuscula

                true: Encontro una mayuscula
                false: Llego al final del string, y no encontro alguna mayuscula
         */
        private fun verifyUpperCase(passCandidate: String): Boolean {
            val passDesintegrated = passCandidate.toCharArray()
            for(i in passDesintegrated){
                if (i.isUpperCase()){
                    return true
                }
            }
            return false
        }

        /*
            Verifica el formato del correo candidato:
                - Que contenga el @
                - Que contenga el dominio (ej: .com .net .ac.cr)

         */
        fun verifyMail(mailCandidate: String): Boolean {
            return !((mailCandidate.indexOf('@')!=mailCandidate.lastIndexOf('@'))||(mailCandidate.indexOf('@')==-1)||(mailCandidate.indexOf('.')==-1))
        }
    }



}