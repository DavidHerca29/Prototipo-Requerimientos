package com.example.hello_world.data

/*
    Indica el formato que tendrá la respuesta del API, se utiliza desde APIService
 */
data class incomingData (
    var Valido:Int          // 1 => Se inserto el usuario  || 0 => El correo ya se encuentra registrado
)