===============
| Source Code |
===============


APIService.kt: Conecion con el API (con el http)

incomingData.kt: Define que es lo que va a recibir del API

Controller.kt: Realiza validaciones de formato (entrada del usuario desde GUI)

DatePickerFragment.kt: Para poder seleccionar la fecha de la manera en la que se implento en el proyecto

MainActivity.kt: Principal, donde inicia el programa: Llama interfaz, toma datos, contiene los listeners y
	      llama al API

=============
|    GUI    |
=============

activity_main.xml: Contiene la interfaz, debe ir localizado en app->main->res->layout


=============
|   CONF    |
=============

AndroidManifest.xml: Archivo de conf, va en app->src->main

build.gradle: Archivo de conf de entorno, incluye las dependencias, va en ->app






