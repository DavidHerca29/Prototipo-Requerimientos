package com.example.hello_world

import android.app.DatePickerDialog
import android.app.Dialog
import android.content.Context
import android.os.Bundle
import android.widget.DatePicker
import android.widget.TextView
import androidx.fragment.app.DialogFragment
import java.util.*

/*
    Definicion del DatePicker para la seleccionar la fecha de nacimiento
 */
class DatePickerFragment(val listener: (day:Int, month:Int, year:Int) -> Unit): DialogFragment(),
    DatePickerDialog.OnDateSetListener{

        override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {

        //Obtiene el tiempo actual
        val calendar = Calendar.getInstance()
        val day= calendar.get(Calendar.DAY_OF_MONTH)
        val month = calendar.get(Calendar.MONTH)
        val year = calendar.get(Calendar.YEAR)

        //Setea que la fecha maxima, es justo 10 years atras
        val theMaxDate = calendar;
        theMaxDate.set(Calendar.YEAR, year-10)

        //Por defecto, inicia el datePicker justo 30 years atras
        val theSelector = DatePickerDialog(activity as Context, this, year-30, month, day)
        theSelector.datePicker.maxDate = theMaxDate.timeInMillis //calendar.timeInMillis
        return theSelector


    }

    /*
        Define el listener una vez que una fecha es seteada
     */
    override fun onDateSet(view: DatePicker?, year: Int,  month: Int, dayOfMonth: Int){
        listener(year, month, dayOfMonth)
    }

}