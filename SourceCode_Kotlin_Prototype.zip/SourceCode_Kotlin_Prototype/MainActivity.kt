package com.example.hello_world

import android.app.DatePickerDialog
import android.content.Context
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.DatePicker
import android.widget.TextView
import android.widget.Toast
import androidx.annotation.RequiresApi
import com.example.hello_world.data.APIService
import com.example.hello_world.data.incomingData
import com.example.hello_world.databinding.ActivityMainBinding
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.lang.Exception
import java.security.MessageDigest
import java.util.*

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    @RequiresApi(Build.VERSION_CODES.O)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        //setContentView(R.layout.activity_main)

        //Acceder a los componentes del interfaz
        val txtNombre = findViewById<TextView>(R.id.txtNombre);
        val txtApellidos = findViewById<TextView>(R.id.txtApellidos);
        val txtCorreo = findViewById<TextView>(R.id.txtCorreo);
        val txtContrasennia = findViewById<TextView>(R.id.txtContrasennia);
        val txtConfirmar = findViewById<TextView>(R.id.txtConfirmar);
        val btnRegistrarme = findViewById<Button>(R.id.btnRegistrarme);
        val txtFecha = findViewById<TextView>(R.id.txtFecha)

        /*
            Accion luego da dar click al boton de 'registrarme'
         */
        btnRegistrarme.setOnClickListener{

            //Verifica que se haya ingresado: nombre, apellidos, fecha de nacimiento y correo
            if(txtNombre.text.toString().isEmpty() || txtApellidos.text.toString().isEmpty() || txtFecha.text.toString().isEmpty() || txtCorreo.text.isEmpty() ){
                Toast.makeText(this, "Todos los campos son obligatorios", Toast.LENGTH_LONG).show()
            }else{
                //Verifica el formato del correo, llama a la funcion en el controller
                if (!Controller.verifyMail(txtCorreo.text.toString())){
                    Toast.makeText(this, "El formato del correo no es válido", Toast.LENGTH_LONG).show()
                }else{
                    //Verifica el formato del password, llama a la funcion en el controller
                    val revisionPass = Controller.verifyPassword(txtContrasennia.text.toString());
                    if(!revisionPass.isEmpty()){
                        Toast.makeText(this, revisionPass, Toast.LENGTH_LONG).show()
                    }else {
                        //Verifica que el password que confirmo el usuario, sea el mismo al que definio
                        if (!txtConfirmar.text.toString().equals(txtContrasennia.text.toString())) {
                            Toast.makeText(
                                this,
                                "Por favor, confirme nuevamente la contraseña",
                                Toast.LENGTH_LONG
                            ).show()
                        } else {
                            //Para este punto, ya todos los datos son validos

                            //Separando los apellidos (para ser almacenados en la base de datos
                            var apellido1: String?
                            var apellido2: String?
                            var listApellidos = txtApellidos.text.toString().split(' ')

                            try {
                                apellido1 = listApellidos.get(0)
                                apellido2 = listApellidos.get(1)
                            } catch (ex: Exception) {
                                apellido1 = listApellidos.get(0)
                                apellido2 = null
                            }
                            //Ya se obtuvo apellido1 y apellido2

                            //Se obtiene la fecha de nacimiento
                            var dateParts = txtFecha.text.toString().split('/');
                            val theYear = dateParts.get(2);
                            val theMonth = dateParts.get(1);
                            val theDay = dateParts.get(0);
                            //Separada en dia, mes, annio

                            //Se recopila todos los datos de registro (para verificacion)
                            val newUser =
                                txtNombre.text.toString() + ";" + apellido1 + ";" + apellido2 + ";" +//
                                        txtCorreo.text.toString() + ";" +//
                                        theYear + ";" +//
                                        theMonth + ";" +//
                                        theDay + ";" +//
                                        txtContrasennia.text.toString()

                            makingTheRequest(
                                "signin?pname=${txtNombre.text.toString()}&pmail=${txtCorreo.text.toString()}&plast1=$apellido1&plast2=$apellido2&pday=$theDay&pmonth=$theMonth&pyear=$theYear&pars=${txtContrasennia.text.toString()}&ptype=3",
                                this
                            )
                            /*
                            Ejemplo de Request
                            pname, pmail, plast1, plast2, pday, pmonth, pyear, pars, ptype
                            http://localhost:5000/api/kind/signin?pname=Olman&pmail=ovilla@ubicabus.com&plast1=Cordero&plast2=Villanueva&pday=13&pmonth=4&pyear=1995&pars=Olman_13&ptype=1
                             */
                        }
                    }
                }

            }
        }
        //Se define el listener para Abrir el datePicker
        txtFecha.setOnClickListener{showDatePickerDialog()}
    }


    /*
        Esto se ejecutara una vez que el usuario presione la opcion de fecha de nacimiento
        Abre el dialogo del DatePicker
     */
    private fun showDatePickerDialog(){
        val datePicker = DatePickerFragment { year, month, day ->
            onDateSelected(
                year,
                month,
                day
            )
        };
        datePicker.show(supportFragmentManager, "BirthdateSelector")
    }

    /*
        Extrae el dia, mes, year seleccionados en el datePicker
        - Lo formatea en dd/mm/yyyy
        - Lo coloca en el textView
     */
    private fun onDateSelected(year: Int, month: Int, day: Int) {
        val txtFecha = findViewById<TextView>(R.id.txtFecha)
        var realMonth = month+1;
        txtFecha.setText(" $day/$realMonth/$year")

    }

    /*
        Creando el objeto retrofit
         - Se define el URL base para conectar con el API (Cuidado con la IP)
         - Gson convierte el response a nuestro formato
     */
    private fun getRetrofit(): Retrofit {
        return Retrofit.Builder()
            .baseUrl("http://192.168.1.7:5000/api/kind/")
            .addConverterFactory(GsonConverterFactory.create())
            .build()
    }

    /*
        Hace la solicitud para insertar el usuario en la base de datos
        - Recibe el query al API (lo que le falta al baseURL)
        - Contexto en el cual se esta ejecutando la UI para retornar un mensaje

        runOnUiThread: Ejecuta el codigo en el hilo donde se ejecuta la interfaz grafica
     */
    private fun makingTheRequest(query:String, pTheContext: Context){

        //Inicia una coroutine para hacer la solicitud (asincrono, en otro hilo de ejecucion)
        CoroutineScope(Dispatchers.IO).launch {

            var theMessageUi: String = ""       //Mensaje feedback para el usuario
            var needClear: Boolean = false      //Indica si es necesario limpiar el form de registro

            val call: Response<incomingData> = getRetrofit().create(APIService::class.java)
                .signinCall("$query")

            //Recibe la respuesta dada por el API
            val signinResponse: incomingData? = call.body()

            //Si la llamada fue realizada con exito
            if (call.isSuccessful){
                if (signinResponse != null) {
                    Log.i("EXITO", signinResponse.Valido.toString())

                    //Ya existe ese correo en la db
                    if (signinResponse.Valido.toString() == "0"){
                        theMessageUi = "Ya existe una cuenta asociada con este correo electrónico"
                    }
                    else{
                        //El usuario se inserto correctamente
                        theMessageUi = "¡Su cuenta ha sido registrada con éxito!"
                        needClear = true
                    }

                }else{
                    /*
                        Esto se ejecutaria unicamente si la llamada se ejecuta, pero
                        no se recibe una respuesta
                     */
                    Log.e("WARNING", "respuesta nula!")
                    theMessageUi = "Ha ocurrido en error inesperado, por favor reinténtelo o póngase en contacto con soporte"
                }

            }else{
                //La llamada no fue exitosa
                Log.e("ERROR", "Ha ocurrido un error")
                theMessageUi = "Error: Lo sentimos, no se pudo realizar el registro de su cuenta. Inténtelo de nuevo más tarde"
                needClear = true
            }

            /*
                El codigo de aqui se ejecutara en el hilo del UI (principal)
             */
            runOnUiThread {
                largeToast(pTheContext, theMessageUi)       //Genera un mensaje android, en la UI, con el mensaje
                if(needClear){
                    clearScreen()                           //Limpiara los valores en los textView
                }
            }
        }

    }

    /*
        Para generar los mensajes android en pantalla
     */
    private fun Context.toast(message: CharSequence) =
        Toast.makeText(this, message, Toast.LENGTH_LONG).show()

    public fun largeToast(context: Context, message: CharSequence){
        context.toast(message)
    }

    fun clearScreen(){
        val txtNombre = findViewById<TextView>(R.id.txtNombre);
        val txtApellidos = findViewById<TextView>(R.id.txtApellidos);
        val txtCorreo = findViewById<TextView>(R.id.txtCorreo);
        val txtContrasennia = findViewById<TextView>(R.id.txtContrasennia);
        val txtConfirmar = findViewById<TextView>(R.id.txtConfirmar);
        val txtFecha = findViewById<TextView>(R.id.txtFecha)

        txtNombre.setText("");
        txtApellidos.setText("");
        txtCorreo.setText("");
        txtContrasennia.setText("");
        txtConfirmar.setText("");
        txtFecha.setText("");
    }

    //-----------------------------------------------------------------------------

    /*
        NO utilizado, esto fue una prueba REGEX para correo
     */
    private fun validateTest(str: String): String{
        val emailFormat = Regex("""\w+@[a-zA-Z]{2,6}""")
        val theEmail:String? = emailFormat.find(str)?.value
        return theEmail.toString()
    }

    /*
        Su fin es realizar un ecriptado del password, usando
        el algoritmo SHA-256
     */
    @RequiresApi(Build.VERSION_CODES.O)
    private fun prueba256(theSecret: String): String? {
        val mdInstance = MessageDigest.getInstance("SHA-256")
        var entry = theSecret.toByteArray(Charsets.UTF_8)
        val bytes = mdInstance.digest(entry)
        //return Base64.getEncoder().encode(bytes).toHexString()
        return Base64.getEncoder().encodeToString(bytes)
        //Log.i("Nice!",Base64.getEncoder().encodeToString(bytes))
    }

    //El password cifrado, lo convierte a un HexString
    fun ByteArray.toHexString() = joinToString(""){"%02x".format(it)}



    //-----------------------------------------------------------------------------


}